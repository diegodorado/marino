/*
 * KitInic.c
 *
 *  Created on: 17/04/2012
 *      Author: Mica y Chor
 */

#include "KitInfo2.h"

unsigned char Tabla_Digitos_BCD_7seg[] = { 0x3f, 0x06, 0x5B, 0x4f, 0x66, 0x6D, 0x7C, 0x07, 0x7f, 0x67};

void InitSysTick ( int useg )
{
	int value;
	//10000 useg ---- STCALIB
	//N  	useg ---- X
	//X = (N * STCALIB)/10000
	value = ( useg * ( STCALIB & 0x0FFFFFFF ) ) / 10000;
	//Pongo el valor de recarga en el valor calculado:
	STRELOAD = value;
	//Hago que se dispare la interrupcion al habilitar:
	STCURR = 0;
	//Disparo el SysTick:
	STCTRL = 0x00000007;
}


void InitADC ( void )
{
	//1.- Activo la alimentacion del dispositivo desde el registro PCONP:
	PCONP |= 1<<12;
	//2.- Selecciono el clock del ADC como 25MHz:
	PCLKSEL0 &= ~(0x03<<24);
	//3.- Y el divisor como 1, para muestrear a 200kHz:
	AD0CR &= 0x00000100;
	//4.- Configuro los pines del ADC0
	//ADC0.5 (pote) : P1[31]->PINSEL3: 30:31
	PINSEL1 |= PINSEL_FUNC1 << 20;

	DIRECCION(ADC3_PORT,ADC3_PIN,ENTRADA);

	//5.- NO ACTIVO LAS INTERRUPCIONES:
	AD0INTEN &= 0xFFFFFE00;
	//6.- Selecciono que voy a tomar muestras del canal AD0.5:
	AD0CR |= 0x00000008;
	//7.- Activo el ADC (PDN = 1):
	AD0CR |= 1<<21;
	//8.- Selecciono que el ADC muestree solo, con BURST = 1 y START = 000:
	//    con esta combinacion el ADC empieza a convertir
	AD0CR &= ~(0x0F<<24);

	AD0CR |= 1<<16;
}

void InitLCD ( void )
{
	unsigned int i,j;

	//1.- Selecciono los bits del puerto como GPIOs y los direcciono:
	PINSEL0 |= PINSEL_GPIO << 10;
	DIRECCION(LCD_D4_PORT,LCD_D4_PIN,SALIDA);

	PINSEL0 |= PINSEL_GPIO << 20;
	DIRECCION(LCD_D5_PORT,LCD_D5_PIN,SALIDA);

	PINSEL4 |= PINSEL_GPIO << 8;
	DIRECCION(LCD_D6_PORT,LCD_D6_PIN,SALIDA);

	PINSEL4 |= PINSEL_GPIO << 10;
	DIRECCION(LCD_D7_PORT,LCD_D7_PIN,SALIDA);

	PINSEL4 |= PINSEL_GPIO << 12;
	DIRECCION(LCD_RS_PORT,LCD_RS_PIN,SALIDA);

	PINSEL3 |= PINSEL_GPIO << 24;
	DIRECCION(LCD_BF_PORT,LCD_BF_PIN,ENTRADA);

	PINSEL0 |= PINSEL_GPIO << 8;
	DIRECCION(LCD_E_PORT,LCD_E_PIN,SALIDA);

	for( i = 0 ; i < 3 ; i++ )
	{
		LCD_E_OFF;
		for ( j = 0 ; j < 500000 ; j++ ); // 300000
		LCD_DATO(1,1,0,0);

		LCD_RS_OFF;
		LCD_E_ON;

		for( j = 0 ; j < 10000 ; j++ );//4500

		LCD_E_OFF;
	}

	LCD_E_OFF;

	for ( j = 0 ; j < 500000 ; j++ ); // 300000

	LCD_DATO(0,1,0,0);

	LCD_RS_OFF;
	LCD_E_ON;

	for( j = 0 ; j < 10000 ; j++ );//4500

	LCD_E_OFF;

	// A partir de aca pasa a 4 bits
	Dato_LCD( 0x28 , LCD_CONTROL );
	Dato_LCD( 0x08 , LCD_CONTROL);	// display OFF
	Dato_LCD( 0x01 , LCD_CONTROL);	// clear display
	for( j = 0 ; j < 10000 ; j++ );	//delay por la instruccion clear display
	Dato_LCD( 0x06 , LCD_CONTROL);	// programo el LCD para mis necesidades
	Dato_LCD( 0x0C , LCD_CONTROL);	// display ON,sin cursor y blinking OFF del cursor

}

void Dato_LCD ( unsigned char data , unsigned char control )
{
	int q , i = 1;
	int data_d4,data_d5,data_d6,data_d7;

	do
	{
		data_d4 = ( data >> ( 0 + i * 4 ) ) & 0x01 ;
		data_d5 = ( data >> ( 1 + i * 4 ) ) & 0x01 ;
		data_d6 = ( data >> ( 2 + i * 4 ) ) & 0x01 ;
		data_d7 = ( data >> ( 3 + i * 4 ) ) & 0x01 ;

		LCD_DATO(data_d4,data_d5,data_d6,data_d7);

		if( control == LCD_CONTROL )
			LCD_RS_OFF;
		else
			LCD_RS_ON;

		LCD_E_ON;
		for( q = 0 ; q < 400 ; q++ );
		LCD_E_OFF;
		for( q = 0 ; q < 14000 ; q++ );
	}
	while ( i-- );
}

void InitPLL ( void )
{

	SCS       = SCS_Value;

	if (SCS_Value & (1 << 5))               /* If Main Oscillator is enabled      */
		while ((SCS & (1<<6)) == 0);/* Wait for Oscillator to be ready    */

	CCLKCFG   = CCLKCFG_Value;      /* Setup Clock Divider                */

	PCLKSEL0  = PCLKSEL0_Value;     /* Peripheral Clock Selection         */
	PCLKSEL1  = PCLKSEL1_Value;

	CLKSRCSEL = CLKSRCSEL_Value;    /* Select Clock Source for PLL0       */

	PLL0CFG   = PLL0CFG_Value;      /* configure PLL0                     */
	PLL0FEED  = 0xAA;
	PLL0FEED  = 0x55;

	PLL0CON   = 0x01;             /* PLL0 Enable                        */
	PLL0FEED  = 0xAA;
	PLL0FEED  = 0x55;

	while (!(PLL0STAT & (1<<26)));/* Wait for PLOCK0                    */

	PLL0CON   = 0x03;             /* PLL0 Enable & Connect              */
	PLL0FEED  = 0xAA;
	PLL0FEED  = 0x55;

	while (!(PLL0STAT & ((1<<25) | (1<<24))));/* Wait for PLLC0_STAT & PLLE0_STAT */

	PLL1CFG   = PLL1CFG_Value;
	PLL1FEED  = 0xAA;
	PLL1FEED  = 0x55;

	PLL1CON   = 0x01;             /* PLL1 Enable                        */
	PLL1FEED  = 0xAA;
	PLL1FEED  = 0x55;

	while (!(PLL1STAT & (1<<10)));/* Wait for PLOCK1                    */

	PLL1CON   = 0x03;             /* PLL1 Enable & Connect              */
	PLL1FEED  = 0xAA;
	PLL1FEED  = 0x55;

	while (!(PLL1STAT & ((1<< 9) | (1<< 8))));/* Wait for PLLC1_STAT & PLLE1_STAT */

	PCONP     = PCONP_Value;        /* Power Control for Peripherals      */

	CLKOUTCFG = CLKOUTCFG_Value;    /* Clock Output Configuration         */

	FLASHCFG  = (FLASHCFG & ~0x0000F000) | FLASHCFG_Value;
}

}
