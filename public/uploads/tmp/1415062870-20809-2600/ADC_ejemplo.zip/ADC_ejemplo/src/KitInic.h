/*
 * KitInic.h
 *
 *  Created on: 17/04/2012
 *      Author: Mica y Chor
 */

#ifndef KITINIC_H_
#define KITINIC_H_

extern void InitPLL	(void);
extern void InitGPIOs 	(void);
extern void InitUART1 	(void);
extern void InitUART0 	(void);
extern void InitDAC   	(void);
extern void InitADC	(void);
extern void InitLCD	(void);
extern void InitSysTick (int);
extern void Dato_LCD ( unsigned char , unsigned char );
extern void InitExpansion ( void );

extern unsigned char Tabla_Digitos_BCD_7seg[];

#define CANT_DIGITOS	6	//Cantidad de digitos del display 7seg
#endif /* KITINIC_H_ */
