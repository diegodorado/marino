/*
===============================================================================
 Name        : main.c
 Author      : 
 Version     :
 Copyright   : Copyright (C) 
 Description : main definition
===============================================================================
*/

#ifdef __USE_CMSIS
#include "LPC17xx.h"
#endif

#include <cr_section_macros.h>
#include <NXP/crp.h>

// Variable to store CRP value in. Will be placed automatically
// by the linker when "Enable Code Read Protect" selected.
// See crp.h header for more information
__CRP const unsigned int CRP_WORD = CRP_NO_CRP ;

#include "KitInfo2.h"

int LeeADC ( void );
void Display_lcd( char *, char , char );

unsigned char digitos[6];
unsigned int valorADC;

int main(void) {
	
	//Inicializo el PLL para tener el CCLK=100MHz
	InitPLL();

	//Inicializo el ADC:
	InitADC();

	//Inicializo el Systick en 1000useg (1kHz):
	InitSysTick(1000);

	while(1) 
	{
		valorADC = LeeADC();
	}
	return 0 ;
}

void SysTick_Handler (void)
{
	Mux7Seg();
}

int LeeADC ( void )
{
	static int resultado = 0;
	int registro;

	registro = AD0DR3;

	if ( ADC_DONE (registro) )
		resultado = ( registro >> 4 ) & 0x00000FFF;

	return resultado;
}


void Display_lcd( char *msg , char renglon , char posicion )
{
	unsigned char i ;

	if( renglon )
        posicion = posicion + 0xc0 ;
	else
		posicion = posicion + 0x80 ;

	Dato_LCD( posicion , LCD_CONTROL );
	for( i = 0 ; msg[ i ] != '\0' ; i++ )
		Dato_LCD( msg[ i ] , LCD_DATA );

}
