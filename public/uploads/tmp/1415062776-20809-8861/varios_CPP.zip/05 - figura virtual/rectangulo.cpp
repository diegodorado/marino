#include "rectangulo.h"

char * Rectangulo::m_sname="rectangulo";


Rectangulo::Rectangulo (double b,double h,Punto& centro):Figura(centro)
{
	setData(b,h);
	prt_my_dbg("Rectangulo (bxh,P)",m_x,m_y); 
}

Rectangulo::Rectangulo (double b,double h,double x, double y):Figura(x,y)
{
	setData(b,h);
	prt_my_dbg("Rectangulo (bxh,d,d)",m_x,m_y); 
}

Rectangulo::Rectangulo (double b,double h):Figura()
{
	setData(b,h);
	prt_my_dbg("Rectangulo (bxh)",m_x,m_y); 
}

Rectangulo::~Rectangulo ()
{
	prt_my_dbg("~Rectangulo --",m_x,m_y); 
}
       
bool Rectangulo::setData (double b,double h)
{
	m_b=b;
	m_h=h;
	
return true;
}

