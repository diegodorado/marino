#include <cstdlib>
#include <iostream>
#include "punto.h"
#include "figura.h"
#include "circulo.h"
#include "rectangulo.h"

using namespace std;

void prt_figura (Figura& ff)
{
	
	cout <<"\n====================== + =============================\n";
	cout <<ff;
	cout <<"\nsu area:"<<ff.getArea()<<"  su perimetro:"<<ff.getPerimetro();


	cout <<"\n====================== = ============================="<<endl;

} 


int f()
{
Punto x(3,4);

	cout <<"PUNTOS:"<< Punto::getCantCreada()<<":"<< Punto::getCantExistente()<< endl;
	cout <<"punto x:"<<x<<endl;

Circulo c1(2.1,x);

	cout <<"circulo:\n"<<c1;
	cout <<"  su area:"<<c1.getArea()<<"  su perimetro:"<<c1.getPerimetro()<<endl;

Punto &pRef = c1;
	cout << "\n las coordenadas de c1 son: " << pRef << endl;



Rectangulo r1(12,15,2.9,9.2);

	cout <<"recr:\n"<<r1;
	cout <<"  su area:"<<r1.getArea()<<"  su perimetro:"<<r1.getPerimetro()<<endl;

Punto &pRef2 = r1;
	cout << "\n las coordenadas de r1 son: " << pRef2 << endl;

    system("PAUSE");
	prt_figura(r1);
	prt_figura(c1);

    system("PAUSE");

Figura *FF[2];

	FF[0]=&r1;
	FF[1]=&c1;
		

	for (int i=0;i<2;i++)
		prt_figura (*FF[i]);
		


    system("PAUSE");
}
int main(int argc, char *argv[])
{
	f();
	cout <<"PUNTOS:"<< Punto::getCantCreada()<<":"<< Punto::getCantExistente()<< endl;

    system("PAUSE");
    return EXIT_SUCCESS;
}
