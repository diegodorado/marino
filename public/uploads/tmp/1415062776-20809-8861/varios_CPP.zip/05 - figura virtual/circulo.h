#ifndef __CIRCULO_H__
#define __CIRCULO_H__

#include <cstdlib>
#include <iostream>
#include "figura.h"

#define PI (double)3.1415926535897932384626433832795


/*========================================================================
---------------------- Circulo --------------------------------

========================================================================*/
class Circulo: public Figura
{
private:
	double m_r;	//radio
	static char * m_sname;

public:
    Circulo (double r,Punto& centro);
    Circulo (double r,double x, double y);
    Circulo (double r);
    ~Circulo ();
       
    double getPerimetro (void) const {return PI*m_r*m_r;};
    double getArea (void)const {return 2*PI*m_r;};
    double getRadio (void)const {return m_r;};
    bool setRadio (double);
	inline friend std::ostream &operator<< ( std::ostream &, const Circulo & );
    
};

std::ostream &operator<< ( std::ostream &out, const Circulo &cc )
{
    out << cc.m_sname <<static_cast<Punto> (cc)<<", su radio:"<<cc.getRadio() <<endl;
return out;
}

#endif



