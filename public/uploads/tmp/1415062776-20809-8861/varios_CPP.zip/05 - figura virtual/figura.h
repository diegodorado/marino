#ifndef __FIGURA_H__
#define __FIGURA_H__

#include <cstdlib>
#include <iostream>
#include "punto.h"


/*========================================================================
---------------------- Figura --------------------------------

========================================================================*/
class Figura: public Punto 
{
private:

public:
    Figura (Punto& centro);
    Figura (double x, double y);
    Figura ();
    ~Figura ();
       
    virtual double getPerimetro (void)const =0;
    virtual double getArea (void)const =0;
	
};


#endif
