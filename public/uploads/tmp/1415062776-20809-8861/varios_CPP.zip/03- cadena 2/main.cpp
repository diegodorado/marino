#include <cstdlib>
#include <iostream>
#include "cadena.h"

using namespace std;

int main(int argc, char *argv[])
{
// creaci�n de un objeto con constructor por defecto
cadena c1("alfa beta gamma");

// creaci�n de un objeto con constructor general
cadena c2("abcdefghijklm");

// operaciones de concatenaci�n
cadena c3 = c1+" "+c2;

// impresion de cadenas
	cout << "\nc1: "<< c1 <<"\nc2: " <<c2<< "\nc3: "<<c3<< endl;

    system ("PAUSE");


//---- Inclusion de una falla 1

int &x=c1.getLen();	// la referencia permite modificar directamente sobre el parametro privado
//	x=2; ---- al sacar el comentario se modifica el valor del miembro privado

cadena c4 = c1+" "+c2;

// impresion de cadenas
	cout << "\nc1: "<< c1 <<"\nc2: " <<c2<< "\nc4: "<<c4<< endl;

//---- Inclusion de una falla 2

char * &s=c2.getStr();	// la referencia permite modificar directamente sobre el parametro privado
	s[4]=0;

	cout << "\nc2: " <<c2<< endl;

    system ("PAUSE");


    return EXIT_SUCCESS;
} 
