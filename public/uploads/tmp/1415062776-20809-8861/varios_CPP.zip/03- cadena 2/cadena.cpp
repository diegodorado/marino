#include <string.h>
#include <iostream>
#include "cadena.h"

/*=============================================================================
====  Nuevas funciones miembro
=============================================================================*/

// funcion miembro privada -�se podria usar una Macro?
void cadena::set_cad(int mode,const char* str) 
{
    m_nchar = strlen(str);	// que pasa si str=NULL??
    
	if (!mode)
	{
		m_nbytes = m_nchar+1;
		m_pstr = new char[m_nbytes];	// que pasa si no hay memoria???
	}
	else
	{
	    if (m_nchar+1 > m_nbytes)	// Que se esta verificando ???
    	{
        	delete [] m_pstr; 
        	m_nbytes=m_nchar+1;
        	m_pstr = new char[m_nbytes];
    	}
	}
 
	strcpy(m_pstr, str);
}

/*---------------------------------------------------------------
 Analisis de fallas en acceso a miembros privados
---------------------------------------------------------------*/

int &cadena::getLen()
{
	prt_my_dbg("getLen()");
	return m_nchar;
}

char* &cadena::getStr()
{
	prt_my_dbg("getStr()");
	return m_pstr;
}

/*=============================================================================

	-------------------	Constructores & Destructores -------------------	

Para analizar - 
	implementacion de partes comunes - 


=============================================================================*/


// constructor por omison
cadena::cadena()
{
	set_cad (0,"");
    prt_my_dbg("Constructor por defecto");
}

// constructor general
cadena::cadena(const char* str)
{
	set_cad (0,str);
    prt_my_dbg("Constructor general");
}


// constructor de copia 
// - en este caso no se puede omitir
// - definir hasta que punto la copia debe generar un objeto identico 

cadena::cadena(const cadena& cd)
{
#if 1	
    m_nchar = cd.m_nchar;
    m_nbytes = m_nchar+1; //  != o == a cd.m_nbytes

    m_pstr = new char[m_nbytes];
    strcpy(m_pstr, cd.m_pstr);
#else
	set_cad (0,cd.m_pstr);
#endif
	
    prt_my_dbg("Constructor de copia");
}

// destructor
// - en este caso no se puede omitir
cadena::~cadena()
{
    prt_my_dbg("Destructor");
    delete [] m_pstr;	// notar como se ejecuta el delete
}


/*=============================================================================

	------------------------- Funciones miembro --------------------------	

=============================================================================*/

//-------------------------- Inicializar cadena 
void cadena::setCadena(const char* c)
{
	set_cad (1,c);
    prt_my_dbg("setCadena()");
}


//--- operador de asignaci�n sobrecargado (=)
// - en este caso no se puede omitir
cadena& cadena::operator= (const cadena& cd)
{
    prt_my_dbg("operator=(cadena)");

    if(*this == cd)		// analizar !!!!
        return *this;    

	set_cad (1,cd.m_pstr);

return *this;    // por que retorna una referencia a si misma????
}

//--- operador de asignaci�n sobrecargado (=)
// - en este caso no se puede omitir

cadena& cadena::operator= (const char * cd)
{
    prt_my_dbg("operator=(char*)");

	set_cad (1,cd);

return *this;    

}

// operador de inserci�n en ostream
std::ostream& operator<< (std::ostream& co, const cadena& cad) 
{
	co << cad.m_pstr;
return co;
}

// implementacion del operador de concatenaci�n de cadenas
cadena operator+ (const cadena& a, const cadena& b)
{
	cadena c;
	c.m_nchar = a.m_nchar + b.m_nchar;
	c.m_nbytes = c.m_nchar+1;
	c.m_pstr = new char[c.m_nbytes];
	strcpy(c.m_pstr, a.m_pstr);
	strcat(c.m_pstr, b.m_pstr);

    prt_my_dbg2("operator+(cadena)",c.m_nchar,c.m_nbytes,c.m_pstr);
	
return c;	// podr�a retornar una referencia a c ???
}


// sobrecarga de los operadores relacionales
bool operator== (const cadena& c1, const cadena& c2)
{
    return (!strcmp(c1.m_pstr, c2.m_pstr));
}

bool operator!= (const cadena& c1, const cadena& c2)
{
    return strcmp(c1.m_pstr, c2.m_pstr);
}
