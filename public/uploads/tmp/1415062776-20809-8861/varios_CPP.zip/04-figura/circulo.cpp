#include "circulo.h"

char * Circulo::m_sname="circulo";


Circulo::Circulo (double r,Punto& centro):Figura(centro)
{
	setRadio(r);
	prt_my_dbg("Circulo (r,P)",m_x,m_y); 
}

Circulo::Circulo (double r,double x, double y):Figura(x,y)
{
	setRadio(r);
	prt_my_dbg("Circulo (r,d,d)",m_x,m_y); 
}

Circulo::Circulo (double r):Figura()
{
	setRadio(r);
	prt_my_dbg("Circulo (r)",m_x,m_y); 
}

Circulo::~Circulo ()
{
	prt_my_dbg("~Circulo --",m_x,m_y); 
}
       
bool Circulo::setRadio (double r)
{
	m_r=r;
return (r>=0);
}

