#ifndef __RECTANGULO_H__
#define __RECTANGULO_H__

#include <cstdlib>
#include <iostream>
#include "figura.h"

/*========================================================================
---------------------- Rectangulo --------------------------------

========================================================================*/
class Rectangulo: public Figura
{
private:
	double m_b,m_h;	// base (b) , altura (h)
	static char * m_sname;

public:
    Rectangulo (double b,double h,Punto& centro);
    Rectangulo (double b,double h,double x, double y);
    Rectangulo (double b,double h);
    ~Rectangulo ();
       
    double getPerimetro (void) const {return 2*(m_b+m_h);};
    double getArea (void) const {return m_b*m_h;};
    double getBase (void) const {return m_b;};
    double getAltura (void)const {return m_h;};
    bool setData (double,double);
	inline friend std::ostream &operator<< ( std::ostream &, const Rectangulo & );
    
};

std::ostream &operator<< ( std::ostream &out, const Rectangulo &rr )
{
    out << rr.m_sname <<static_cast<Punto> (rr)<<", base x altura:"<<rr.m_b<<" x "<<rr.m_h <<endl;
return out;
}

#endif

