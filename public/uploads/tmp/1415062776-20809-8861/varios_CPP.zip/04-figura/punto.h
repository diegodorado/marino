#ifndef __PUNTO_H__
#define __PUNTO_H__

#include <cstdlib>
#include <iostream>

#include "my_dbg.h"

using std::cout;
using std::cerr;
using std::endl;


/*========================================================================
---------------------- Punto --------------------------------
m_x: coordenada en x
m_x: coordenada en y

m_cc: contados de objetos creados
m_ce: contados de objetos existentes

========================================================================*/
class Punto
{
private:
	void set_const(double,double);

protected:
	double m_x,m_y;    // coordenadas x e y;
	static int m_cc,m_ce;	// cantidad de objetos

public:
	Punto ();
	Punto (double coor_x, double coor_y);
	Punto (const Punto &p);
	~Punto ();
	void setX (double coor_x)	// inline implicito
		{m_x=coor_x;};
    	
	inline void setY (double coor_y);
	double getX (void) const{return m_x;};
	inline double getY (void) const;

	void setPunto (double coor_x,double coor_y)
   	{
		m_x=coor_x;
		m_y=coor_y;
	};
    inline Punto& getPunto (void);

	
	friend std::ostream &operator<< ( std::ostream &, const Punto & );

	static int getCantCreada ()  {return m_cc;};
	static int getCantExistente (){return m_ce;};
	
};

// implementaciones tipo inline 

inline void Punto::setY (double coor_y)
{
	m_y=coor_y;
}

inline double Punto::getY (void) const{return m_y;}

inline Punto& Punto::getPunto (void){return (*this);}


#endif
