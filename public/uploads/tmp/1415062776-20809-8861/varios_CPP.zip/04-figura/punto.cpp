#include "punto.h"

using std::cout;

int Punto::m_cc=0;
int Punto::m_ce=0;

void Punto::set_const(double x,double y)
{	
	m_x=x;
	m_y=y;
	m_cc++;
	m_ce++;
}


Punto::Punto ()
{	
	set_const(0,0);
	prt_my_dbg("Punto ()",m_x,m_y); 
}

Punto::Punto (double coor_x, double coor_y)
{
	set_const(coor_x,coor_y);
	prt_my_dbg("Punto (d,d)",m_x,m_y); 
}

Punto::Punto (const Punto &p)
{
//	set_const(0,0);
	*this=p;
	m_cc++;
	m_ce++;

	prt_my_dbg("Punto (&p)",m_x,m_y); 
}

Punto::~Punto ()
{
	m_ce--;
	prt_my_dbg("~Punto ---",m_x,m_y); 
}


std::ostream &operator<< ( std::ostream &out, const Punto &p )
{
	out << "[ " << p.m_x << ", " << p.m_y << " ]";

return out;
} 



