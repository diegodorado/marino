#include "figura.h"


Figura::Figura (Punto& centro):Punto(centro)
{
	prt_my_dbg("Figura (P)",m_x,m_y); 
}

Figura::Figura (double x, double y):Punto(x,y)
{
	prt_my_dbg("Figura (d,d)",m_x,m_y); 
}

Figura::Figura ():Punto()
{
	prt_my_dbg("Figura ()",m_x,m_y); 
}

Figura::~Figura ()
{
	prt_my_dbg("~Figura --",m_x,m_y); 
}

