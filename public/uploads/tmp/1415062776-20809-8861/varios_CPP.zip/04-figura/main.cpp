#include <cstdlib>
#include <iostream>
#include "punto.h"
#include "figura.h"
#include "circulo.h"
#include "rectangulo.h"

using namespace std;

Punto *h;


void f()
{
// --- pruebas a traves de objetos Punto ---
Punto x(3,4);

	cout <<"PUNTOS:"<< Punto::getCantCreada()<<":"<< Punto::getCantExistente()<< endl;

	h=new Punto ();
	
	cout <<"punto x:"<<x<<"   punto h:"<<*h<<endl;
	
	h->setX(34);
	h->setY(34);
	cout <<"punto h:"<<*h<<" o :"<<h->getX()<<" , "<<h->getY()<< endl;


// --- pruebas a traves de objetos Figura ---
Figura f1(x);
Figura f2;
Figura f3(2.4,3.2);
	
	cout <<"PUNTOS:"<< Punto::getCantCreada()<<":"<< Punto::getCantExistente()<< endl;
	cout <<"puntos:"<< f2.getCantCreada()<<":"<< h->getCantExistente()<< endl;

	cout <<"Figura f1:"<<f1<<" su area:" <<f1.getArea()<<endl;
	cout <<"Figura f2:"<<f2<<endl;
	cout <<"Figura f3:"<<f3<<endl;


// --- pruebas a traves de objetos Figura ---

Circulo c1(2.1,f1);

	cout <<"circ c1:"<<c1<<" su area:" <<c1.getArea()<<endl;


Punto &pRef = c1;	
	cout << "\n las coordenadas de c1 son: " << pRef << endl;

// --- pruebas a traves de objetos Rectangulo ---
Rectangulo r1(6,8,f3);

	cout <<"rect r1:"<<r1<<" su area:" <<r1.getArea()<<endl;

	cout <<"PUNTOS:"<< Punto::getCantCreada()<<":"<< Punto::getCantExistente()<< endl;

Punto &pRef2 = r1;	
	cout << "\n las coordenadas de r1 son: " << pRef2 << endl;


    system("PAUSE");
}
int main(int argc, char *argv[])
{
	f();

	cout <<"PUNTOS:"<< Punto::getCantCreada()<<":"<< Punto::getCantExistente()<< endl;

    system("PAUSE");
    delete h;

    return EXIT_SUCCESS;
}
