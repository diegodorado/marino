/*
etiqueta MY_DBG....

	Es una etiqueta a nivel de bit que habilita la salida de mensajes
	segun el bit que este habilitado


*/

#ifndef __MY_DBG__
#define __MY_DBG__


#define MY_DBG_CONST 0

#if MY_DBG_CONST
#define prt_my_dbg(x,y,z) cerr<<"\ndbg:"<<__LINE__<<"|:"<<x<<"|:"<<y<<"|:"<<z<<":("<<this<<")"<<endl
#else
#define prt_my_dbg(x,y,z)
#endif

//#define prt_my_dbg(ff,x,y,z) if(ff)cerr<<"\ndbg:"<<__LINE__<<"|:"<<x<<"|:"<<y<<"|:"<<z<<"|:"<<this<<endl

#endif
