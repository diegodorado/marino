#include <cstdlib>
#include <iostream>

#include "cadena.h"

using std::cout;
using std::endl;
#include <new>
using std::bad_alloc;

#define MAX_ARR 1000

int main(int argc, char *argv[])
{
cadena *c [MAX_ARR];
char s[200];
int i;
	try
	{
		for (i=0; i<MAX_ARR;i++)
		{
			sprintf (s,"texto %d",i);
			c[i]=new cadena (s);
	
			cout << "c: "<< c[i]<< ": "<< *c[i]<<endl;
			
		}
	}
	catch ( bad_alloc e ) 
	{
		cout << "excepcion:" << e.what() << endl;
	} 

	for (int k=0; k<i;k++)
		delete c[k];


	system ("PAUSE");
		
cadena cad1("prueba de igual");
cadena cad2;

	
	try
	{
		cad2=cad1;
		cad1=cad1;
	}
	catch ( int e ) 
	{
		cout << "excepcion int:" << e << endl;
	} 
	catch ( float e ) 
	{
		cout << "excepcion float:" << e << endl;
	} 
	catch ( ... ) 
	{
		cout << "Otro tipo de excepcion" << endl;
	} 
	
	system ("PAUSE");




    return EXIT_SUCCESS;
} 
