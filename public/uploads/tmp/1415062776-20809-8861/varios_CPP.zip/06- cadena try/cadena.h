#include <iostream>

#ifndef __CADENA_H
#define __CADENA_H

//#define MY_DBG

#ifdef MY_DBG
#define prt_my_dbg(x) std::cerr<<"dbg:"<<__LINE__<<"|"<<x<<"|"<<m_nchar<<":"<<m_nbytes<<":("<<this<<"):"<<m_pstr<<std::endl
#define prt_my_dbg2(x,y,z,s) std::cerr<<"dbg:"<<__LINE__<<"|:"<<x<<"|:"<<y<<"|:"<<z<<"|:"<<s<<"|:"<<std::endl
#else
#define prt_my_dbg(x)
#define prt_my_dbg2(x,y,z,s)


#endif


#define BLOCK_SIZE 5120000

class cadena 
{
private:
	char* m_pstr;
	int m_nchar; 	// n� de caracteres (sin el '\0')
	int m_nbytes; //********* n� de bloques reservados
	void set_cad(int , const char*); 
	
public:
	cadena();				// constructor por defecto
	cadena(const char*); 			// constructor general
	cadena(const cadena&);	// constructor de copia
	~cadena();				// destructor

    void setCadena(const char*);		// dar valor a la variable privada pstr


    // sobrecarga de operadores
    cadena& operator= (const cadena&);
    cadena& operator= (const char * cd);

    friend cadena operator+ (const cadena&, const cadena&);

    friend bool operator== (const cadena&, const cadena&);
    friend bool operator!= (const cadena&, const cadena&);

    friend std::ostream& operator<< (std::ostream&, const cadena&);


};

#endif

