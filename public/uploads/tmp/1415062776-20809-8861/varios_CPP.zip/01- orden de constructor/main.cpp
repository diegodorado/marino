#include <cstdlib>
#include <iostream>

using std::cout;
using std::endl;



// Definici�n de la clase Alfa.

class Alfa 
{
private:
	int datos;
public:
	Alfa( int valor) // constructor
	{
		datos = valor;
		cout << "  Objeto: " << datos << " constructor" << endl;
	}
	
	~Alfa() 	// destructor
	{ 
		cout << "~ Objeto: " << datos << " destructor " << endl; 
	}
};

//============================================================================


void func( void ); // prototipo

Alfa primero( 1 ); // objeto global

int main(int argc, char *argv[])
{
	cout << "-> Inicia la funcion main " << endl;
	Alfa segundo( 2 ); // objeto local
	cout << "-> main luego de crear objeto local 2" << endl;
	
	static Alfa tercero( 3 ); // objeto local
	cout << "-> main luego de crear objeto local static 3" << endl;

	func(); 

	Alfa cuarto( 4 ); // objeto local
	cout << "-> main luego de crear objeto local 4" << endl;
	cout << "-> Pausa antes de finalizar main" << endl;
	
	system ("PAUSE");
	return 0;
}

void func( void )
{
	cout << "-> Inicia func" << endl;

	Alfa quinto( 5 );
	cout << "-> main luego de crear obj loc 5" << endl;

	static Alfa sexto( 6 );
	cout << "-> main luego de crear obj loc static 6" << endl;

	Alfa septimo( 7 );
	cout << "-> main luego de crear obj loc 6" << endl;
	cout << "-> Termina func" << endl;
}
	



