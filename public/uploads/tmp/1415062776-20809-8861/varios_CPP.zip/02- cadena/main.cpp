#include <cstdlib>
#include <iostream>
#include "cadena.h"

using namespace std;

int main(int argc, char *argv[])
{
// creaci�n de un objeto con constructor por defecto
cadena c1;

// creaci�n de un objeto con constructor general
cadena c2("abcdefghijln");

// operaciones de concatenaci�n
    c2 = (c2 + "_") + "mnopqrstuvw ";

// creaci�n de un objeto con constructor de copia
cadena c3 = c2; 	// tambien: cadena c3(c2);

// primero se convierte a objeto y luego se asigna
    c1 = "xyz 1234567890";


// impresion de cadenas
	cout << "\nc1: "<< c1 <<"\nc2: " <<c2<< "\nc3: "<<c3<< endl;
	cout << "\nc1+c2+c3: "<< c1+c2+c3 << endl;

// igualacion de objetos
    c3=c2=c1;
    
    if(c3 == c1) 
    {
        cout << "c3 y c1 son iguales" << endl;
        // un contructor es un conversor de tipo
        c3 = cadena("Hola a todos");
    }


    system ("PAUSE");

    return EXIT_SUCCESS;
} // se detruyen c1, c2 y c3
